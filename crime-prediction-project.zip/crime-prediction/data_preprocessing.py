"""
Step 2: Data Preprocessing
Loads crime data, cleans it, and extracts time features for prediction.
"""
import pandas as pd
from pathlib import Path

from config import COLUMN_MAPPING, REQUIRED_COLUMNS


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Map dataset columns to standard names."""
    result = df.copy()
    for old_name, std_name in COLUMN_MAPPING.items():
        if old_name in result.columns and std_name not in result.columns:
            result = result.rename(columns={old_name: std_name})
    return result


def load_data(filepath: str) -> pd.DataFrame:
    """Load crime data from CSV."""
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {filepath}")
    data = pd.read_csv(filepath)
    return data


def preprocess(data: pd.DataFrame) -> pd.DataFrame:
    """
    Clean data and add time features.
    Drops rows missing required columns; converts Date; adds year, month, day, hour.
    """
    data = normalize_columns(data)

    # Keep only rows that have required fields
    for col in REQUIRED_COLUMNS:
        if col not in data.columns:
            raise ValueError(
                f"Missing required column '{col}'. "
                f"Available columns: {list(data.columns)}. "
                f"Add mapping in config.py if your dataset uses different names."
            )
    data = data[data[REQUIRED_COLUMNS].notna().all(axis=1)].copy()

    # Convert date column
    data["Date"] = pd.to_datetime(data["Date"], errors="coerce")
    data = data.dropna(subset=["Date"])

    # Time features for prediction
    data["year"] = data["Date"].dt.year
    data["month"] = data["Date"].dt.month
    data["day"] = data["Date"].dt.day
    data["hour"] = data["Date"].dt.hour
    data["day_of_week"] = data["Date"].dt.dayofweek

    return data.reset_index(drop=True)


def run_preprocessing(input_path: str, output_path: str = "crime_data_cleaned.csv") -> pd.DataFrame:
    """Load, preprocess, and save cleaned data."""
    data = load_data(input_path)
    data = preprocess(data)
    data.to_csv(output_path, index=False)
    print(f"Cleaned data saved to {output_path}. Shape: {data.shape}")
    return data


if __name__ == "__main__":
    import sys
    input_file = sys.argv[1] if len(sys.argv) > 1 else "crime_data.csv"
    run_preprocessing(input_file)

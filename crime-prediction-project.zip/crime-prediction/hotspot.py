"""
Step 6: Crime Hotspot Detection (K-Means)
Groups high-crime areas into clusters.
"""
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.cluster import KMeans
import joblib

MODEL_DIR = Path("models")
MODEL_DIR.mkdir(exist_ok=True)


def load_cleaned_data(path: str = "crime_data_cleaned.csv") -> pd.DataFrame:
    """Load preprocessed crime data."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Cleaned data not found: {path}")
    return pd.read_csv(p)


def detect_hotspots(
    data: pd.DataFrame,
    n_clusters: int = 5,
    coord_cols: tuple = ("Latitude", "Longitude"),
    random_state: int = 42,
):
    """
    Fit K-Means on Latitude/Longitude and assign cluster labels.
    Returns data with 'cluster' column and fitted KMeans model.
    """
    coords = data[[coord_cols[0], coord_cols[1]]].dropna()
    kmeans = KMeans(n_clusters=n_clusters, random_state=random_state)
    labels = kmeans.fit_predict(coords)
    data = data.copy()
    data["cluster"] = np.nan
    data.loc[coords.index, "cluster"] = labels
    joblib.dump(kmeans, MODEL_DIR / "kmeans_hotspots.joblib")
    joblib.dump(n_clusters, MODEL_DIR / "hotspot_n_clusters.joblib")
    return data, kmeans


def get_cluster_centers(kmeans) -> list:
    """Return list of (lat, lon) for each cluster center."""
    return [
        (float(lat), float(lon))
        for lat, lon in zip(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1])
    ]


def run_hotspot_detection(
    data_path: str = "crime_data_cleaned.csv", n_clusters: int = 5
) -> pd.DataFrame:
    """Run hotspot detection and return data with cluster labels."""
    data = load_cleaned_data(data_path)
    data, kmeans = detect_hotspots(data, n_clusters=n_clusters)
    centers = get_cluster_centers(kmeans)
    print(f"Hotspot clusters: {n_clusters}. Centers saved in model.")
    return data


if __name__ == "__main__":
    run_hotspot_detection()

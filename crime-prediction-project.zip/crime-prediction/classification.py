"""
Step 4 & 5: Crime Classification (LightGBM) and High-Risk Area Prediction (Random Forest)
"""
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from lightgbm import LGBMClassifier
import joblib

MODEL_DIR = Path("models")
MODEL_DIR.mkdir(exist_ok=True)


def load_cleaned_data(path: str = "crime_data_cleaned.csv") -> pd.DataFrame:
    """Load preprocessed crime data."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Cleaned data not found: {path}")
    return pd.read_csv(p)


def train_classification_model(
    data: pd.DataFrame,
    feature_cols: list = None,
    target_col: str = "Crime_Type",
    test_size: float = 0.2,
    random_state: int = 42,
):
    """
    Train LightGBM to predict crime category from hour, month, day.
    Returns model, label_encoder, and accuracy.
    """
    if feature_cols is None:
        feature_cols = ["hour", "month", "day", "day_of_week"]
    available = [c for c in feature_cols if c in data.columns]
    X = data[available]
    y = data[target_col]
    le = LabelEncoder()
    y_enc = le.fit_transform(y.astype(str))
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_enc, test_size=test_size, random_state=random_state
    )
    model = LGBMClassifier(n_estimators=100, random_state=random_state, verbose=-1)
    model.fit(X_train, y_train)
    accuracy = model.score(X_test, y_test)
    joblib.dump(model, MODEL_DIR / "lgbm_classifier.joblib")
    joblib.dump(le, MODEL_DIR / "label_encoder.joblib")
    joblib.dump(available, MODEL_DIR / "classification_features.joblib")
    return model, le, accuracy


def train_risk_model(
    data: pd.DataFrame,
    feature_cols: list = None,
    target_col: str = "Crime_Type",
    test_size: float = 0.2,
    random_state: int = 42,
):
    """
    Train Random Forest to predict risk (crime type) from location and time.
    Uses Latitude, Longitude, hour.
    """
    if feature_cols is None:
        feature_cols = ["Latitude", "Longitude", "hour", "month"]
    available = [c for c in feature_cols if c in data.columns]
    X = data[available]
    y = data[target_col]
    le = LabelEncoder()
    y_enc = le.fit_transform(y.astype(str))
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_enc, test_size=test_size, random_state=random_state
    )
    rf = RandomForestClassifier(n_estimators=100, random_state=random_state)
    rf.fit(X_train, y_train)
    accuracy = rf.score(X_test, y_test)
    joblib.dump(rf, MODEL_DIR / "rf_risk.joblib")
    joblib.dump(le, MODEL_DIR / "rf_label_encoder.joblib")
    joblib.dump(available, MODEL_DIR / "rf_features.joblib")
    return rf, le, accuracy


def run_training(data_path: str = "crime_data_cleaned.csv"):
    """Train both classification and risk models."""
    data = load_cleaned_data(data_path)
    _, _, acc1 = train_classification_model(data)
    _, _, acc2 = train_risk_model(data)
    print(f"LightGBM classification accuracy: {acc1:.4f}")
    print(f"Random Forest risk prediction accuracy: {acc2:.4f}")
    print(f"Models saved to {MODEL_DIR}/")


if __name__ == "__main__":
    run_training()

"""
Step 7: Heatmap Visualization (Folium)
Creates an HTML map with crime heatmap layer.
"""
import pandas as pd
from pathlib import Path
import folium
from folium.plugins import HeatMap


def load_cleaned_data(path: str = "crime_data_cleaned.csv") -> pd.DataFrame:
    """Load preprocessed crime data."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Cleaned data not found: {path}")
    return pd.read_csv(p)


def build_heatmap(
    data: pd.DataFrame,
    output_path: str = None,
    lat_col: str = "Latitude",
    lon_col: str = "Longitude",
    zoom_start: int = 10,
    radius: int = 15,
    blur: int = 25,
):
    """
    Build Folium map with heatmap layer. Optionally save to HTML file.
    Returns the Folium map object (use map.get_root().render() for HTML string).
    """
    coords = data[[lat_col, lon_col]].dropna()
    if coords.empty:
        raise ValueError("No valid coordinates in data.")
    center_lat = coords[lat_col].mean()
    center_lon = coords[lon_col].mean()
    m = folium.Map(location=[center_lat, center_lon], zoom_start=zoom_start)
    heat_data = coords.values.tolist()
    HeatMap(heat_data, radius=radius, blur=blur).add_to(m)
    if output_path:
        m.save(output_path)
    return m


def run_heatmap(data_path: str = "crime_data_cleaned.csv", output_path: str = "heatmap.html"):
    """Generate and save crime heatmap."""
    data = load_cleaned_data(data_path)
    build_heatmap(data, output_path=output_path)
    print(f"Heatmap saved to {output_path}")


if __name__ == "__main__":
    run_heatmap()

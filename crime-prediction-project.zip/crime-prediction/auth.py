"""
User authentication and admin approval.
Uses SQLite for user storage (can be switched to MySQL later).
"""
import hashlib
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "users.db"


def _hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


def _get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create users table and default admin if not exists."""
    conn = _get_conn()
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                phone TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                is_admin INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            )
        """)
        conn.commit()
        cur = conn.execute("SELECT 1 FROM users WHERE is_admin = 1 LIMIT 1")
        if cur.fetchone() is None:
            from datetime import datetime
            conn.execute(
                "INSERT INTO users (username, password_hash, phone, status, is_admin, created_at) VALUES (?, ?, ?, ?, 1, ?)",
                ("admin", _hash_password("admin@123"), "0000000000", "approved", datetime.utcnow().isoformat()),
            )
            conn.commit()
    finally:
        conn.close()


def register(username: str, password: str, phone: str) -> tuple[bool, str]:
    """
    Register a new user with status 'pending'. Returns (success, message).
    """
    if not username or not password or not phone:
        return False, "All fields are required."
    if len(username) < 3:
        return False, "Username must be at least 3 characters."
    if len(password) < 6:
        return False, "Password must be at least 6 characters."
    if len(phone.strip()) < 10:
        return False, "Enter a valid phone number."

    from datetime import datetime
    conn = _get_conn()
    try:
        conn.execute(
            "INSERT INTO users (username, password_hash, phone, status, is_admin, created_at) VALUES (?, ?, ?, 'pending', 0, ?)",
            (username.strip().lower(), _hash_password(password), phone.strip(), datetime.utcnow().isoformat()),
        )
        conn.commit()
        return True, "Registration successful. Please wait for admin approval."
    except sqlite3.IntegrityError:
        return False, "Username already exists."
    finally:
        conn.close()


def login(username: str, password: str) -> tuple[bool, str, dict | None]:
    """
    Verify credentials. Returns (success, message, user_dict or None).
    user_dict: {username, status, is_admin}.
    """
    if not username or not password:
        return False, "Username and password required.", None

    conn = _get_conn()
    try:
        cur = conn.execute(
            "SELECT username, password_hash, status, is_admin FROM users WHERE username = ?",
            (username.strip().lower(),),
        )
        row = cur.fetchone()
        if row is None:
            return False, "Invalid username or password.", None
        if row["password_hash"] != _hash_password(password):
            return False, "Invalid username or password.", None
        if row["status"] == "rejected":
            return False, "Your account has been rejected. Contact admin.", None
        if row["status"] == "pending" and not row["is_admin"]:
            return False, "Your account is pending approval. Please wait for admin to approve.", None

        user = {
            "username": row["username"],
            "status": row["status"],
            "is_admin": bool(row["is_admin"]),
        }
        return True, "Login successful.", user
    finally:
        conn.close()


def reset_password(username: str, phone: str, new_password: str) -> tuple[bool, str]:
    """
    Reset a user's password after verifying username and phone.
    Returns (success, message).
    """
    if not username or not phone or not new_password:
        return False, "All fields are required."
    if len(new_password) < 6:
        return False, "Password must be at least 6 characters."

    conn = _get_conn()
    try:
        cur = conn.execute(
            "SELECT id, status FROM users WHERE username = ? AND phone = ?",
            (username.strip().lower(), phone.strip()),
        )
        row = cur.fetchone()
        if row is None:
            return False, "No matching user found for that username and phone."
        if row["status"] == "rejected":
            return False, "This account has been rejected. Contact admin."

        conn.execute(
            "UPDATE users SET password_hash = ? WHERE id = ?",
            (_hash_password(new_password), row["id"]),
        )
        conn.commit()
        return True, "Password updated. You can now sign in with the new password."
    finally:
        conn.close()


def get_pending_users():
    """Return list of dicts: id, username, phone, created_at for status='pending'."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            "SELECT id, username, phone, created_at FROM users WHERE status = 'pending' ORDER BY created_at"
        )
        return [dict(row) for row in cur.fetchall()]
    finally:
        conn.close()


def set_user_status(user_id: int, status: str) -> bool:
    """Set user status to 'approved' or 'rejected'. Returns True if updated."""
    if status not in ("approved", "rejected"):
        return False
    conn = _get_conn()
    try:
        cur = conn.execute("UPDATE users SET status = ? WHERE id = ? AND status = 'pending'", (status, user_id))
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()

"""
Step 3: Crime Pattern Analysis (EDA)
Analyzes crime types, peak hours, and monthly trends.
"""
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

sns.set_theme(style="darkgrid")


def load_cleaned_data(path: str = "crime_data_cleaned.csv") -> pd.DataFrame:
    """Load preprocessed crime data."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(
            f"Cleaned data not found at {path}. Run data_preprocessing.py first."
        )
    return pd.read_csv(p)


def plot_crime_types(data: pd.DataFrame, top_n: int = 15, save_path: str = None):
    """Bar chart of most common crime types."""
    counts = data["Crime_Type"].value_counts().head(top_n)
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.barplot(x=counts.values, y=counts.index.astype(str), ax=ax, palette="viridis")
    ax.set_xlabel("Count")
    ax.set_ylabel("Crime Type")
    ax.set_title("Most Common Crime Types")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig


def plot_peak_hours(data: pd.DataFrame, save_path: str = None):
    """Line/bar chart of crimes by hour of day."""
    hourly = data.groupby("hour").size()
    fig, ax = plt.subplots(figsize=(10, 4))
    sns.lineplot(x=hourly.index, y=hourly.values, ax=ax, marker="o")
    ax.set_xlabel("Hour of Day")
    ax.set_ylabel("Crime Count")
    ax.set_title("Crime by Hour of Day (Peak Hours)")
    ax.set_xticks(range(0, 24, 2))
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig


def plot_monthly_trend(data: pd.DataFrame, save_path: str = None):
    """Crime count by month."""
    monthly = data.groupby("month").size()
    fig, ax = plt.subplots(figsize=(10, 4))
    sns.barplot(x=monthly.index, y=monthly.values, ax=ax, palette="mako")
    ax.set_xlabel("Month")
    ax.set_ylabel("Crime Count")
    ax.set_title("Crime by Month")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig


def run_analysis(data_path: str = "crime_data_cleaned.csv", output_dir: str = "charts"):
    """Generate all EDA charts and save to output_dir."""
    Path(output_dir).mkdir(exist_ok=True)
    data = load_cleaned_data(data_path)
    plot_crime_types(data, save_path=f"{output_dir}/crime_types.png")
    plot_peak_hours(data, save_path=f"{output_dir}/peak_hours.png")
    plot_monthly_trend(data, save_path=f"{output_dir}/monthly_trend.png")
    print(f"Charts saved to {output_dir}/")


if __name__ == "__main__":
    run_analysis()

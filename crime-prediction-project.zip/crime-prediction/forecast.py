"""
Step 8: Crime Trend Forecasting (Prophet)
Forecasts future crime counts by date.
"""
import pandas as pd
from pathlib import Path
import joblib

try:
    from prophet import Prophet
    HAS_PROPHET = True
except ImportError:
    Prophet = None
    HAS_PROPHET = False

MODEL_DIR = Path("models")
MODEL_DIR.mkdir(exist_ok=True)


def load_cleaned_data(path: str = "crime_data_cleaned.csv") -> pd.DataFrame:
    """Load preprocessed crime data."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Cleaned data not found: {path}")
    return pd.read_csv(p)


def prepare_trend_data(data: pd.DataFrame, date_col: str = "Date") -> pd.DataFrame:
    """Aggregate crime count by date for Prophet (columns: ds, y)."""
    data = data.copy()
    data[date_col] = pd.to_datetime(data[date_col])
    trend = data.groupby(data[date_col].dt.date).size().reset_index(name="crime_count")
    trend.columns = ["ds", "y"]
    trend["ds"] = pd.to_datetime(trend["ds"])
    return trend


def train_forecast_model(
    trend: pd.DataFrame,
    periods: int = 30,
    save_path: str = None,
):
    """
    Fit Prophet on daily crime count and predict future periods.
    Returns forecast DataFrame and fitted model.
    """
    if Prophet is None:
        raise ImportError("Prophet is not installed. Run: pip install prophet")
    model = Prophet(yearly_seasonality=True, weekly_seasonality=True)
    model.fit(trend)
    future = model.make_future_dataframe(periods=periods)
    forecast = model.predict(future)
    if save_path is None:
        save_path = MODEL_DIR / "prophet_forecast.joblib"
    joblib.dump(model, save_path)
    return forecast, model


def run_forecast(
    data_path: str = "crime_data_cleaned.csv",
    periods: int = 30,
):
    """Run Prophet forecast and optionally plot."""
    data = load_cleaned_data(data_path)
    trend = prepare_trend_data(data)
    forecast, model = train_forecast_model(trend, periods=periods)
    print(f"Forecast generated for next {periods} days.")
    return forecast, model


if __name__ == "__main__":
    forecast, _ = run_forecast(periods=30)
    print(forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].tail(10))

"""
Configuration for crime prediction system.
Maps common dataset column names to a standard schema.
"""
# Column mapping: dataset_column -> standard_column
# Add mappings for your dataset if column names differ
COLUMN_MAPPING = {
    "Primary Type": "Crime_Type",
    "primary_type": "Crime_Type",
    "Category": "Crime_Type",
    "Offense Type": "Crime_Type",
    "Date": "Date",
    "date": "Date",
    "Datetime": "Date",
    "Latitude": "Latitude",
    "latitude": "Latitude",
    "Lat": "Latitude",
    "Longitude": "Longitude",
    "longitude": "Longitude",
    "Lon": "Longitude",
    "Lng": "Longitude",
    "Location": "Location",
    "Block": "Location",
    "District": "Area",
    "Community Area": "Area",
    "Description": "Description",
}

REQUIRED_COLUMNS = ["Crime_Type", "Date", "Latitude", "Longitude"]
OPTIONAL_COLUMNS = ["Location", "Area", "Description"]
